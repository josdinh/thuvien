<?php
class CV_Thuvien_Helper_Tacpham extends Mage_Core_Helper_Abstract
{

}