
jQuery(document).ready(function(){
    if(jQuery('.bxslider').length) {
        jQuery('.bxslider').bxSlider({
            pager: false
        });
    }

});
